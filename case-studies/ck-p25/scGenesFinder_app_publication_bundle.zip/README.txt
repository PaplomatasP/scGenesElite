Method: SCMarker; displayed genes: 20
Expression transform: log2
Grouping: sample
Heatmap: transform mapped input expression, standardize each gene across cells, then average by group.
Constant genes displayed as zero: 
Boxplots: median, interquartile range, 1.5 IQR whiskers; cells are not independent biological replicates.
Inspected genes: Il6ra, Sall1, Lcp1
Classifier seed: 20260908
k-NN: selected predictors, 80% stratified training split, center/scale, up to five-fold training CV.
Classification uses the selected method's output matrix; expression plots use the mapped input values.
Selection precedes the cell split; independent samples are not held out. This is not independent validation.
R version 4.6.1 (2026-06-24 ucrt)
Platform: x86_64-w64-mingw32/x64
Running under: Windows 11 x64 (build 26200)

Matrix products: default
  LAPACK version 3.12.1

locale:
[1] C
system code page: 65001

time zone: Europe/Berlin
tzcode source: internal

attached base packages:
[1] stats     graphics  grDevices utils     datasets  methods   base     

other attached packages:
[1] caret_7.0-1    lattice_0.22-9 ggplot2_4.0.3  shiny_1.14.0  

loaded via a namespace (and not attached):
 [1] gtable_0.3.6         recipes_1.3.3        vctrs_0.7.3         
 [4] tools_4.6.1          generics_0.1.4       stats4_4.6.1        
 [7] parallel_4.6.1       proxy_0.4-29         tibble_3.3.1        
[10] pkgconfig_2.0.3      ModelMetrics_1.2.2.2 Matrix_1.7-6        
[13] data.table_1.18.4    RColorBrewer_1.1-3   S7_0.2.2            
[16] lifecycle_1.0.5      compiler_4.6.1       farver_2.1.2        
[19] stringr_1.6.0        textshaping_1.0.5    codetools_0.2-20    
[22] httpuv_1.6.17        htmltools_0.5.9      class_7.3-23        
[25] prodlim_2026.03.11   later_1.4.8          pillar_1.11.1       
[28] MASS_7.3-65          gower_1.0.2          iterators_1.0.14    
[31] rpart_4.1.27         foreach_1.5.2        nlme_3.1-169        
[34] mime_0.13            parallelly_1.48.0    lava_1.9.3          
[37] tidyselect_1.2.1     digest_0.6.39        stringi_1.8.9       
[40] future_1.75.0        dplyr_1.2.1          reshape2_1.4.5      
[43] purrr_1.2.2          listenv_1.0.0        labeling_0.4.3      
[46] splines_4.6.1        fastmap_1.2.0        grid_4.6.1          
[49] cli_3.6.6            magrittr_2.0.5       survival_3.8-6      
[52] future.apply_1.20.2  e1071_1.7-17         withr_3.0.3         
[55] scales_1.4.0         promises_1.5.0       lubridate_1.9.5     
[58] timechange_0.4.0     globals_0.19.1       otel_0.2.0          
[61] nnet_7.3-20          gridExtra_2.3.1      timeDate_4052.112   
[64] ragg_1.5.2           hardhat_1.4.3        rlang_1.3.0         
[67] Rcpp_1.1.2           xtable_1.8-8         glue_1.8.1          
[70] pROC_1.19.0.1        ipred_0.9-16         R6_2.6.1            
[73] plyr_1.8.9           systemfonts_1.3.2   
